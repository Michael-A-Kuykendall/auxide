use auxide::graph::{Graph, NodeType, Port, PortId, Rate};
use auxide::plan::Plan;
use auxide::rt::Runtime;
use criterion::{Criterion, black_box, criterion_group, criterion_main};
use std::collections::HashMap;

fn bench_process_block(c: &mut Criterion) {
    let mut graph = Graph::new();
    let node1 = graph.add_node(
        vec![Port {
            id: PortId(0),
            rate: Rate::Audio,
        }],
        NodeType::SineOsc {
            freq: 440.0,
            phase: 0.0,
        },
    );
    let plan = Plan::compile(&graph).unwrap();
    let mut runtime = Runtime::new(plan, &graph);
    let inputs = HashMap::new();
    let mut outputs = HashMap::new();

    c.bench_function("process_block_64", |b| {
        b.iter(|| {
            runtime.process_block(black_box(&inputs), black_box(&mut outputs), 64);
        })
    });
}

criterion_group!(benches, bench_process_block);
criterion_main!(benches);
